import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity, ScrollView , ImageBackground } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';

export default function App() {
  const [text, setText] = useState('');
  const [endereco, setEndereco] = useState('');
  const [data, setData] = useState('');
  const [hora , setHora] = useState('');


  function handleChangeText(newText) {
    setText(newText);
  }

  function handleEnderecoChange(newText) {
    setEndereco(newText);
  }

function handledataChange (newText){
  setData(newText);
}
function handlehoraChange (newText){
  setHora(newText);
}

function handlePress() {
    console.log(`O texto digitado é: ${text}`);
  }

  return (
    <ScrollView>
    <View style={styles.container}>
      <MaterialCommunityIcons name="dog-side" size={100} color="#006aff" />

      <Text style={styles.title}> PetMovel </Text>
      <View style={styles.card}>
        <View style={styles.cardHeader}>
          <Text style={styles.cardTitle}>Origem:</Text>
        </View>

        <TextInput
          style={styles.input}
          placeholder="Digite seu endereço"
          value={endereco}
          onChangeText={setEndereco}
          placeholderTextColor={'black'}
        />
      </View>
      <View style={styles.card}>
        <View style={styles.cardHeader}>
          <Text style={styles.cardTitle}>Destino:</Text>
        </View>
        
         <TextInput
          style={styles.input}
          placeholder="Digite seu destino"
          value={text}
          onChangeText={setText}
          placeholderTextColor={'black'}
        />
      </View>
      <View style={styles.card}>
        <View style={styles.cardHeader}>
          <Text style={styles.cardTitle}>Data:</Text>
        </View>
       <TextInput
          style={styles.input}
          placeholder="DD - MM"
          keyboardType="numeric"
          value={data}
          maxLength={6}
          onChangeText={setData}
          placeholderTextColor={'black'}
        />
      </View>
      <View style={styles.card}>
        <View style={styles.cardHeader}>
          <Text style={styles.cardTitle}>Hora:</Text>
        </View>
         <TextInput 
          style={styles.input}
          placeholder="00:00"
          keyboardType="numeric"
          value={hora}
          maxLength={4}
          onChangeText={setHora}
          placeholderTextColor={'black'}
        />
        <TouchableOpacity style={styles.button} onPress={handlePress}>
        <Text style={styles.buttonText}> Chamar </Text>
        </TouchableOpacity>
      </View>
     
     </View>
    </ScrollView>
     );
 }

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginVertical: 20,
  },

  card: {
    backgroundColor: '#f2f2f2',
    width: '80%',
    borderRadius: 10,
    padding: 20,
    marginVertical: 10,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold'
  },
  cardText: {
   
  },
  input: {
    borderWidth: 1,
    borderColor: '#0000FF',
    borderRadius: 10,
    padding: 9,
    marginVertical: 9,
    width: '100%'
  },
  button: {
    backgroundColor: '#0066CC',
    borderRadius: 10,
    paddingVertical: 10,
    paddingHorizontal: 20,
    marginVertical: 60,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign : 'center',
   }
});

