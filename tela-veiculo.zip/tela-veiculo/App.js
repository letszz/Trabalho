import React from 'react';
import { StyleSheet, View, Text, Image, TouchableOpacity, ScrollView, FlatList } from 'react-native';

const HomeScreen = ({ navigation }) => {
  const handleNavigate = () => {
    navigation.navigate('Detalhes');
  };
  const data = [
    { id: '1', title: 'Carro', image: require('./assets/carro.png') },
    { id: '2', title: 'Van', image: require('./assets/van1.png') },
    { id: '4', title: 'Moto', image: require('./assets/moto.png') },
  ];

  const renderItem = ({ item }) => (
    <TouchableOpacity style={styles.vehicleItem} onPress={() => navigation.navigate('MapScreen')}>
      <Image source={item.image} style={styles.vehicleImage} />
      <Text style={styles.vehicleTitle}>{item.title}</Text>
    </TouchableOpacity>
  );

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>PetMovel</Text>
      </View>
      <Text style={styles.subtitle}>Escolha o tipo de veiculo</Text>
      <FlatList data={data} renderItem={renderItem} keyExtractor={(item) => item.id} numColumns={2} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 20,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 30,
  },
  logo: {
    width: 50,
    height: 50,
    marginRight: 10,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  subtitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 30,
    marginBottom: 10,
  },
  vehicleItem: {
    flex: 1,
    alignItems: 'center',
    margin: 10,
  },
  vehicleImage: {
    width: 100,
    height: 100,
    marginBottom: 10,
  },
  vehicleTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});

export default HomeScreen;